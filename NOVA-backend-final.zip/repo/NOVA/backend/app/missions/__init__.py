"""Mission logic package."""
