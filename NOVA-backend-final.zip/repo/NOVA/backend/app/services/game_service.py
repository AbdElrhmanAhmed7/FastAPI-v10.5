"""Game orchestration: persistence + domain systems + mission engine.

Every mutating operation runs inside :meth:`GameService.transaction`, which
* serialises concurrent requests for the same game (async lock),
* loads and validates the save document,
* records events,
* and commits with optimistic-concurrency protection.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import timedelta
from typing import Any

from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from app import __version__
from app.config import Settings
from app.core.errors import (
    GameRuleError,
    InvalidInputError,
    MissionCompletedError,
    MissionLockedError,
    SessionLimitError,
    SessionNotFoundError,
    StateConflictError,
)
from app.core.locks import KeyedLock
from app.core.logging import get_logger
from app.core.security import issue_session_token
from app.core.utils import clamp, new_id, round_to, seeded_rng, utcnow
from app.db.repositories import (
    EarthReportRepository,
    EventRepository,
    GameRepository,
    IdempotencyRepository,
    MissionResultRepository,
    ScienceSampleRepository,
    SimulationRunRepository,
)
from app.db.session import Database
from app.domain.enums import Activity, Difficulty, MissionStatus
from app.domain.state import EquipmentState, GameState
from app.missions.engine import MissionEngine
from app.missions.registry import GameContent
from app.systems.achievements import AchievementSystem
from app.systems.continuity import ContinuitySystem
from app.systems.event_bus import EventBus
from app.systems.events import EventRecorder
from app.systems.inventory_system import InventorySystem
from app.systems.oxygen_system import OxygenSystem
from app.systems.resource_manager import ResourceManager

logger = get_logger("nova.game")

#: Portable save bundle identity (``GET /games/{id}/export`` → ``POST /games/import``).
SAVE_FORMAT = "nova-save"
SAVE_FORMAT_VERSION = 1


@dataclass(slots=True)
class Transaction:
    """Everything a gameplay operation needs, scoped to one request."""

    session: AsyncSession
    state: GameState
    recorder: EventRecorder

    @property
    def games(self) -> GameRepository:
        return GameRepository(self.session)

    @property
    def events(self) -> EventRepository:
        return EventRepository(self.session)

    @property
    def results(self) -> MissionResultRepository:
        return MissionResultRepository(self.session)

    @property
    def samples(self) -> ScienceSampleRepository:
        return ScienceSampleRepository(self.session)

    @property
    def runs(self) -> SimulationRunRepository:
        return SimulationRunRepository(self.session)

    @property
    def earth(self) -> EarthReportRepository:
        return EarthReportRepository(self.session)

    @property
    def idempotency(self) -> IdempotencyRepository:
        return IdempotencyRepository(self.session)


def create_initial_state(
    content: GameContent,
    *,
    player_name: str,
    difficulty: Difficulty,
    seed: int | None = None,
    game_id: str | None = None,
) -> GameState:
    catalog = content.catalog
    resolved_seed = (
        seed
        if seed is not None
        else seeded_rng(player_name, utcnow().isoformat()).randint(1, 2**31)
    )
    state = GameState(
        game_id=game_id or new_id("nova"),
        player_name=player_name,
        difficulty=difficulty,
        seed=resolved_seed,
        resources=catalog.starting_resources(),
        resource_caps=catalog.resource_caps(),
        inventory={},
        equipment={},
    )
    state.world = {
        "leak_active": False,
        "fire_active": False,
        "comms_online": False,
        "base_site": None,
        "hazards": {},
        "_oxygen_fraction": 0.0,
    }
    return state


def _id_map(rows: Any, key: str, prefix: str) -> dict[str, str]:
    """Fresh ids for every exported record that carries ``key``."""
    mapping: dict[str, str] = {}
    for row in rows or []:
        if isinstance(row, dict) and isinstance(row.get(key), str):
            mapping.setdefault(row[key], new_id(prefix))
    return mapping


def _remap_save_references(
    state: GameState, sample_map: dict[str, str], report_map: dict[str, str]
) -> None:
    """Point every in-document reference at the re-keyed side records."""
    state.sample_ids = [sample_map.get(sid, sid) for sid in state.sample_ids]
    state.report_ids = [report_map.get(rid, rid) for rid in state.report_ids]

    geology = state.world.get("geology")
    if isinstance(geology, dict):
        for key in ("last_sample_id", "logged_sample_id"):
            if geology.get(key) in sample_map:
                geology[key] = sample_map[geology[key]]
    earth = state.world.get("earth")
    if isinstance(earth, dict) and earth.get("report_id") in report_map:
        earth["report_id"] = report_map[earth["report_id"]]

    for progress in state.missions.values():
        for key in ("last_sample_id", "logged_sample_id"):
            if progress.data.get(key) in sample_map:
                progress.data[key] = sample_map[progress.data[key]]
        if progress.data.get("earth_report_id") in report_map:
            progress.data["earth_report_id"] = report_map[progress.data["earth_report_id"]]
        analysis = progress.data.get("sample_analysis")
        if isinstance(analysis, dict) and analysis.get("sample_id") in sample_map:
            analysis["sample_id"] = sample_map[analysis["sample_id"]]


class GameService:
    """Authoritative gameplay orchestration for one NOVA deployment."""

    def __init__(
        self,
        database: Database,
        content: GameContent,
        settings: Settings,
        *,
        nasa: Any | None = None,
        bus: EventBus | None = None,
    ) -> None:
        self.db = database
        self.content = content
        self.settings = settings
        self.engine = MissionEngine(content)
        self.locks = KeyedLock()
        # Doorbell for the WebSocket tail. A private bus when nobody injected
        # one (unit tests, scripts): publishing to zero subscribers is free.
        self.bus = bus if bus is not None else EventBus()

        from app.services.action_hooks import ActionHooks
        from app.services.earth_service import EarthService
        from app.services.science_service import ScienceService

        self.science = ScienceService(database, content)
        self.earth = EarthService(database, content, settings, nasa=nasa)
        self.hooks = ActionHooks(self)

    # ------------------------------------------------------------------
    # Transaction plumbing
    # ------------------------------------------------------------------
    @asynccontextmanager
    async def transaction(self, game_id: str) -> AsyncIterator[Transaction]:
        """Serialised, optimistic-concurrency unit of work for one game.

        Gameplay rule violations (wrong order, missing item, worn tool) are
        *expected* outcomes: their consequences (mistakes, hazard effects,
        events) must be persisted even though the request returns an error.
        Anything else rolls back untouched.
        """
        async with self.locks.acquire(game_id), self.db.session() as session:
            repository = GameRepository(session)
            state = await repository.load(game_id)
            if state is None:
                raise SessionNotFoundError(f"Game session not found: {game_id}", game_id=game_id)
            expected_version = state.version
            recorder = EventRecorder(state)
            transaction = Transaction(session=session, state=state, recorder=recorder)

            try:
                yield transaction
            except GameRuleError:
                await self._persist(transaction, repository, expected_version)
                raise
            else:
                await self._persist(transaction, repository, expected_version)

    async def _persist(
        self,
        transaction: Transaction,
        repository: GameRepository,
        expected_version: int,
    ) -> None:
        state = transaction.state
        # Badges are a derived view: re-evaluating on every mutation keeps them
        # correct no matter which endpoint changed the save.
        self.achievement_system(state).sync(transaction.recorder)
        saved = await repository.save(state, expected_version)
        if not saved:
            raise StateConflictError(
                "The game state was modified by another request. Retry.",
                game_id=state.game_id,
                expected_version=expected_version,
            )
        events = transaction.recorder.drain()
        await transaction.events.append(state.game_id, events)
        if events and state.event_seq % 200 == 0:
            await transaction.events.trim(state.game_id, self.settings.max_events_per_session)
        # Commit here, not only on the happy path: ``transaction()`` re-raises
        # GameRuleError *after* persisting, and the surrounding session context
        # would otherwise roll the consequences of a failed action away.
        await transaction.session.commit()
        # Notify *after* the commit: a subscriber must never see an event that
        # was rolled back. The bus never raises, so gameplay cannot fail here.
        self.bus.publish(state.game_id, events)

    def _publish(self, game_id: str, events: list[dict[str, Any]]) -> None:
        """Ring the doorbell for a commit that happened outside ``_persist``."""
        if events:
            self.bus.publish(game_id, events)

    async def read_state(self, game_id: str) -> GameState:
        async with self.db.session() as session:
            state = await GameRepository(session).load(game_id)
        if state is None:
            raise SessionNotFoundError(f"Game session not found: {game_id}", game_id=game_id)
        return state

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------
    async def create_game(
        self,
        *,
        player_name: str,
        difficulty: Difficulty | None = None,
        seed: int | None = None,
    ) -> dict[str, Any]:
        async with self.db.session() as session:
            repository = GameRepository(session)
            if await repository.count() >= self.settings.max_sessions:
                raise SessionLimitError(
                    f"Server reached the {self.settings.max_sessions} session limit.",
                    limit=self.settings.max_sessions,
                )

            state = create_initial_state(
                self.content,
                player_name=player_name,
                difficulty=difficulty or Difficulty(self.settings.default_difficulty),
                seed=seed,
            )
            self.engine.bootstrap(state)
            recorder = EventRecorder(state)
            recorder.emit(
                "game.created",
                {
                    "player_name": state.player_name,
                    "difficulty": state.difficulty.value,
                    "seed": state.seed,
                    "missions_available": [
                        m["id"]
                        for m in self.engine.catalogue_view(state)
                        if m["status"] != "locked"
                    ],
                },
            )
            await repository.create(state)
            created_events = recorder.drain()
            await EventRepository(session).append(state.game_id, created_events)

        logger.info("game.created", extra={"game_id": state.game_id})
        self._publish(state.game_id, created_events)
        return {
            "game_id": state.game_id,
            "session_token": issue_session_token(
                state.game_id, self.settings.secret_key, self.settings.token_ttl_hours
            ),
            "state": self.snapshot_payload(state),
        }

    async def list_games(
        self, *, player_name: str | None = None, limit: int = 50, offset: int = 0
    ) -> list[dict[str, Any]]:
        async with self.db.session() as session:
            return await GameRepository(session).list(
                player_name=player_name, limit=limit, offset=offset
            )

    async def delete_game(self, game_id: str) -> bool:
        async with self.locks.acquire(game_id), self.db.session() as session:
            deleted = await GameRepository(session).delete(game_id)
        if not deleted:
            raise SessionNotFoundError(f"Game session not found: {game_id}", game_id=game_id)
        return True

    async def resume(self, game_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        return {
            "game_id": state.game_id,
            "session_token": issue_session_token(
                state.game_id, self.settings.secret_key, self.settings.token_ttl_hours
            ),
            "state": self.snapshot_payload(state),
        }

    async def purge_expired(self) -> int:
        cutoff = utcnow() - timedelta(hours=self.settings.session_ttl_hours)
        async with self.db.session() as session:
            removed = await GameRepository(session).purge_older_than(cutoff)
            await IdempotencyRepository(session).purge_older_than(cutoff)
        return removed

    # ------------------------------------------------------------------
    # Views
    # ------------------------------------------------------------------
    def achievement_system(self, state: GameState) -> AchievementSystem:
        return AchievementSystem(state, self.content.achievements, self.content.missions)

    def snapshot_payload(self, state: GameState) -> dict[str, Any]:
        inventory = InventorySystem(state, self.content.catalog)
        resources = ResourceManager(state, self.content.catalog)
        return {
            **state.public_snapshot(),
            "missions_catalogue": self.engine.catalogue_view(state),
            "hud": {
                "critical_resources": resources.critical(),
                "degraded_tools": inventory.degraded_tools(),
                "oxygen_alarm": state.suit.oxygen_alarm,
                "readiness": state.continuity.readiness,
                "readiness_grade": state.continuity.readiness_grade,
                "achievements": self.achievement_system(state).summary(),
                "active_mission": next(
                    (
                        mission_id
                        for mission_id, progress in state.missions.items()
                        if progress.status == MissionStatus.active
                    ),
                    None,
                ),
            },
        }

    async def snapshot(self, game_id: str, *, event_limit: int = 25) -> dict[str, Any]:
        async with self.db.session() as session:
            state = await GameRepository(session).load(game_id)
            if state is None:
                raise SessionNotFoundError(f"Game session not found: {game_id}", game_id=game_id)
            events = await EventRepository(session).list(
                game_id, after_seq=max(0, state.event_seq - event_limit), limit=event_limit
            )
        payload = self.snapshot_payload(state)
        payload["recent_events"] = events
        return payload

    async def events(
        self, game_id: str, *, after_seq: int = 0, limit: int = 100, types: list[str] | None = None
    ) -> dict[str, Any]:
        if not await self._exists(game_id):
            raise SessionNotFoundError(f"Game session not found: {game_id}", game_id=game_id)
        async with self.db.session() as session:
            events = await EventRepository(session).list(
                game_id, after_seq=after_seq, limit=limit, types=types
            )
        return {
            "game_id": game_id,
            "after_seq": after_seq,
            "events": events,
            "next_seq": events[-1]["seq"] if events else after_seq,
            "has_more": len(events) == limit,
        }

    async def _exists(self, game_id: str) -> bool:
        async with self.db.session() as session:
            return await GameRepository(session).exists(game_id)

    # ------------------------------------------------------------------
    # Gameplay
    # ------------------------------------------------------------------
    async def tick(
        self, game_id: str, *, dt_seconds: float, activity: str = "idle"
    ) -> dict[str, Any]:
        dt = clamp(float(dt_seconds), 0.0, self.settings.max_tick_seconds)
        if activity not in {a.value for a in Activity}:
            raise InvalidInputError(f"Unknown activity '{activity}'.")

        async with self.transaction(game_id) as tx:
            state = tx.state
            oxygen = OxygenSystem(state, self.content.catalog)
            telemetry = oxygen.tick(dt, activity)
            state.stats.playtime_seconds = round_to(state.stats.playtime_seconds + dt, 2)
            state.last_tick_at = utcnow()

            active = [
                mission_id
                for mission_id, progress in state.missions.items()
                if progress.status == MissionStatus.active
            ]
            for mission_id in active:
                progress = state.mission(mission_id)
                progress.elapsed_seconds = round_to(progress.elapsed_seconds + dt, 2)

            if telemetry["alarm"] == "critical":
                tx.recorder.emit("oxygen.critical", telemetry)
            elif telemetry["alarm"] == "warning" and state.world.get("_oxygen_warned") is not True:
                state.world["_oxygen_warned"] = True
                tx.recorder.emit("oxygen.warning", telemetry)
            elif telemetry["alarm"] is None:
                state.world["_oxygen_warned"] = False

            return {"game_id": game_id, "telemetry": telemetry, "resources": dict(state.resources)}

    async def start_mission(self, game_id: str, mission_id: str) -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            view = self.engine.start(tx.state, mission_id, tx.recorder)
            self._ensure_simulation(tx, mission_id)
            view["simulation_state"] = tx.state.simulations.get(mission_id)
            return {"mission": view, "resources": dict(tx.state.resources)}

    def _ensure_simulation(self, tx: Transaction, mission_id: str) -> None:
        """Prepare (but do not run) the simulation attached to a mission."""
        from app.domain.enums import SimulationStatus
        from app.simulations import factory

        definition = self.content.missions.get(mission_id)
        if definition is None or definition.simulation is None:
            return
        existing = tx.state.simulations.get(mission_id)
        # A mission action may have written control flags before the run was
        # materialised; that partial document is not a valid simulation yet.
        if existing and existing.get("kind"):
            return
        simulation = factory.create(
            definition.simulation,
            mission_id,
            tx.state.seed,
            {"difficulty": tx.state.difficulty.value},
        )
        simulation.status = SimulationStatus.ready
        if existing:
            factory.preserve_controls(definition.simulation, existing, simulation)
        tx.state.simulations[mission_id] = factory.dump(simulation)
        tx.recorder.emit(
            "simulation.ready",
            {"mission_id": mission_id, "kind": definition.simulation.value},
            mission_id=mission_id,
        )

    async def execute_action(
        self,
        game_id: str,
        mission_id: str,
        action: str,
        *,
        payload: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            key = f"{game_id}:{idempotency_key}" if idempotency_key else None
            if key:
                cached = await tx.idempotency.get(key)
                if cached is not None:
                    tx.recorder.events.clear()
                    return {**cached, "replayed": True}

            result = self.engine.execute(tx.state, mission_id, action, tx.recorder, payload)
            self._ensure_simulation(tx, mission_id)

            extra = await self.hooks.after_action(tx, mission_id, action, result)
            if extra:
                result["side_effects"] = extra

            if result.get("report"):
                await tx.results.upsert(game_id, result["report"])
            self._check_campaign(tx)
            if key:
                await tx.idempotency.store(key, game_id, result)
            return result

    def _check_campaign(self, tx: Transaction) -> None:
        """Flag the save as finished once every mission is complete."""
        if tx.state.finished:
            return
        if all(
            tx.state.mission(mission_id).status == MissionStatus.completed
            for mission_id in self.content.missions.missions
        ):
            tx.state.finished = True
            tx.recorder.emit(
                "campaign.completed",
                {
                    "readiness": tx.state.continuity.readiness,
                    "grade": tx.state.continuity.readiness_grade,
                    "missions": len(self.content.missions.missions),
                },
            )

    async def mission_view(self, game_id: str, mission_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        return self.engine.mission_view(state, mission_id)

    async def mission_catalogue(self, game_id: str) -> list[dict[str, Any]]:
        state = await self.read_state(game_id)
        return self.engine.catalogue_view(state)

    async def interaction_map(self, game_id: str, mission_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        return self.engine.interaction_map(state, mission_id)

    async def mission_report(self, game_id: str, mission_id: str) -> dict[str, Any]:
        async with self.db.session() as session:
            if not await GameRepository(session).exists(game_id):
                raise SessionNotFoundError(f"Game session not found: {game_id}", game_id=game_id)
            report = await MissionResultRepository(session).get(game_id, mission_id)
        if report is None:
            from app.core.errors import ReportNotFoundError

            raise ReportNotFoundError(
                f"No report yet for mission '{mission_id}'. Complete it first.",
                game_id=game_id,
                mission_id=mission_id,
            )
        return report

    async def all_reports(self, game_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        async with self.db.session() as session:
            reports = await MissionResultRepository(session).list(game_id)
        completed = [r for r in reports if r.get("status") == "completed"]
        average = (
            round_to(sum(r["score_pct"] for r in completed) / len(completed), 2)
            if completed
            else 0.0
        )
        return {
            "game_id": game_id,
            "player_name": state.player_name,
            "missions_completed": len(completed),
            "missions_total": len(self.content.missions.missions),
            "average_score_pct": average,
            "readiness": state.continuity.readiness,
            "readiness_grade": state.continuity.readiness_grade,
            "total_playtime_seconds": state.stats.playtime_seconds,
            "achievements": self.achievement_system(state).summary(),
            "reports": reports,
            "stats": state.stats.model_dump(mode="json"),
        }

    async def continuity(self, game_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        return ContinuitySystem(state, self.content.catalog).summary()

    # ------------------------------------------------------------------
    # Achievements
    # ------------------------------------------------------------------
    async def achievements_view(self, game_id: str) -> dict[str, Any]:
        """Every badge with its live progress (locked ones included)."""
        state = await self.read_state(game_id)
        system = self.achievement_system(state)
        views = [view.model_dump(mode="json") for view in system.views()]
        return {
            "game_id": game_id,
            **system.summary(),
            "tiers": self.content.achievements.tiers,
            "achievements": views,
        }

    # ------------------------------------------------------------------
    # Mission retry
    # ------------------------------------------------------------------
    async def restart_mission(self, game_id: str, mission_id: str) -> dict[str, Any]:
        """Reset an *incomplete* mission so a player can never be stuck.

        Resources already spent stay spent, mistakes stay on the record and the
        attempt counter grows – retrying is possible, not free. Completed
        missions are immutable history.
        """
        definition = self.engine.require_definition(mission_id)
        async with self.transaction(game_id) as tx:
            progress = tx.state.mission(mission_id)
            if progress.status == MissionStatus.completed:
                raise MissionCompletedError(
                    f"Mission '{mission_id}' is already completed; its report is final.",
                    mission_id=mission_id,
                )
            if progress.status == MissionStatus.locked:
                missing = [
                    dep
                    for dep in definition.requires_missions
                    if tx.state.mission(dep).status != MissionStatus.completed
                ]
                raise MissionLockedError(
                    f"Mission '{mission_id}' is locked. Complete {', '.join(missing)} first.",
                    mission_id=mission_id,
                    requires=missing,
                )

            previous_objectives = len(progress.completed_objectives)
            attempts = progress.attempts
            mistakes = progress.mistakes
            elapsed = progress.elapsed_seconds
            progress.status = MissionStatus.available
            tx.state.simulations.pop(mission_id, None)
            view = self.engine.start(tx.state, mission_id, tx.recorder)
            fresh = tx.state.mission(mission_id)
            fresh.attempts = attempts + 1
            fresh.mistakes = mistakes
            fresh.elapsed_seconds = elapsed
            self._ensure_simulation(tx, mission_id)
            tx.recorder.emit(
                "mission.restarted",
                {
                    "mission_id": mission_id,
                    "attempt": fresh.attempts,
                    "objectives_reset": previous_objectives,
                    "mistakes_kept": mistakes,
                },
                mission_id=mission_id,
            )
            view["simulation_state"] = tx.state.simulations.get(mission_id)
            return {
                "mission": view,
                "attempt": fresh.attempts,
                "resources": dict(tx.state.resources),
            }

    # ------------------------------------------------------------------
    # Portable saves (export / import)
    # ------------------------------------------------------------------
    async def export_save(self, game_id: str) -> dict[str, Any]:
        """A self-contained save bundle: state + every queryable side record."""
        state = await self.read_state(game_id)
        async with self.db.session() as session:
            results = await MissionResultRepository(session).list(game_id)
            samples = await ScienceSampleRepository(session).list(game_id)
            runs = await SimulationRunRepository(session).list(game_id)
            reports = await EarthReportRepository(session).list(game_id)
        return {
            "format": SAVE_FORMAT,
            "format_version": SAVE_FORMAT_VERSION,
            "backend_version": __version__,
            "exported_at": utcnow().isoformat(),
            "game_id": game_id,
            "player_name": state.player_name,
            "state": state.model_dump(mode="json"),
            "mission_results": results,
            "science_samples": samples,
            "simulation_runs": runs,
            "earth_reports": reports,
        }

    async def import_save(
        self, bundle: dict[str, Any], *, player_name: str | None = None
    ) -> dict[str, Any]:
        """Restore an exported bundle as a **new** session.

        A fresh ``game_id`` is always issued: importing must never overwrite an
        existing save, and the client keeps working with the id it is given.
        """
        if bundle.get("format") != SAVE_FORMAT:
            raise InvalidInputError(
                f"Not a NOVA save bundle (expected format '{SAVE_FORMAT}').",
                format=bundle.get("format"),
            )
        version = bundle.get("format_version")
        if version != SAVE_FORMAT_VERSION:
            raise InvalidInputError(
                f"Unsupported save format version {version!r}; expected {SAVE_FORMAT_VERSION}.",
                format_version=version,
            )
        raw_state = bundle.get("state")
        if not isinstance(raw_state, dict):
            raise InvalidInputError("Save bundle is missing its 'state' document.")

        try:
            state = GameState.model_validate(raw_state)
        except ValidationError as exc:
            raise InvalidInputError(
                "Save bundle state is not a valid NOVA game document.",
                errors=[{"loc": list(err["loc"]), "msg": err["msg"]} for err in exc.errors()[:12]],
            ) from exc

        state.game_id = new_id("nova")
        if player_name:
            state.player_name = player_name
        state.version = 1
        state.touch()
        # Unknown mission ids in an imported save would be unreachable forever.
        known = set(self.content.missions.missions)
        state.missions = {
            mission_id: progress
            for mission_id, progress in state.missions.items()
            if mission_id in known
        }
        self.engine.bootstrap(state)
        self.engine.refresh_unlocks(state)

        # Side tables use globally unique primary keys: re-key every record so
        # importing the same bundle twice can never collide, then rewrite the
        # references inside the save document to match.
        sample_map = _id_map(bundle.get("science_samples"), "sample_id", "smp")
        run_map = _id_map(bundle.get("simulation_runs"), "run_id", "run")
        report_map = _id_map(bundle.get("earth_reports"), "report_id", "earth")
        _remap_save_references(state, sample_map, report_map)

        async with self.db.session() as session:
            repository = GameRepository(session)
            if await repository.count() >= self.settings.max_sessions:
                raise SessionLimitError(
                    f"Server reached the {self.settings.max_sessions} session limit.",
                    limit=self.settings.max_sessions,
                )
            recorder = EventRecorder(state)
            recorder.emit(
                "game.imported",
                {
                    "source_game_id": bundle.get("game_id"),
                    "player_name": state.player_name,
                    "missions_completed": state.stats.missions_completed,
                },
            )
            await repository.create(state)
            imported_events = recorder.drain()
            await EventRepository(session).append(state.game_id, imported_events)
            restored = await self._restore_side_records(
                session, state.game_id, bundle, sample_map, run_map, report_map
            )

        logger.info(
            "game.imported",
            extra={"game_id": state.game_id, "source": bundle.get("game_id"), **restored},
        )
        self._publish(state.game_id, imported_events)
        return {
            "game_id": state.game_id,
            "session_token": issue_session_token(
                state.game_id, self.settings.secret_key, self.settings.token_ttl_hours
            ),
            "restored": restored,
            "state": self.snapshot_payload(state),
        }

    async def _restore_side_records(
        self,
        session: AsyncSession,
        game_id: str,
        bundle: dict[str, Any],
        sample_map: dict[str, str],
        run_map: dict[str, str],
        report_map: dict[str, str],
    ) -> dict[str, int]:
        """Re-insert exported rows under the new game id and the new record ids."""
        restored = {
            "mission_results": 0,
            "science_samples": 0,
            "simulation_runs": 0,
            "earth_reports": 0,
        }
        results = MissionResultRepository(session)
        for report in bundle.get("mission_results") or []:
            if (
                isinstance(report, dict)
                and report.get("mission_id") in self.content.missions.missions
            ):
                await results.upsert(game_id, report)
                restored["mission_results"] += 1

        samples = ScienceSampleRepository(session)
        for sample in bundle.get("science_samples") or []:
            if isinstance(sample, dict) and sample.get("sample_id") in sample_map:
                await samples.restore(
                    game_id, {**sample, "sample_id": sample_map[str(sample["sample_id"])]}
                )
                restored["science_samples"] += 1

        runs = SimulationRunRepository(session)
        for run in bundle.get("simulation_runs") or []:
            if isinstance(run, dict) and run.get("run_id") in run_map:
                await runs.restore(game_id, {**run, "run_id": run_map[str(run["run_id"])]})
                restored["simulation_runs"] += 1

        earth = EarthReportRepository(session)
        for report in bundle.get("earth_reports") or []:
            if isinstance(report, dict) and report.get("report_id") in report_map:
                await earth.restore(
                    game_id, {**report, "report_id": report_map[str(report["report_id"])]}
                )
                restored["earth_reports"] += 1
        return restored

    # ------------------------------------------------------------------
    # Inventory / suit
    # ------------------------------------------------------------------
    async def use_item(
        self, game_id: str, item_id: str, *, target: str | None = None
    ) -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            inventory = InventorySystem(tx.state, self.content.catalog)
            outcome = inventory.use(item_id, target)
            tx.recorder.emit("item.used", outcome)
            return {
                **outcome,
                "inventory": dict(tx.state.inventory),
                "resources": dict(tx.state.resources),
                "equipment": {k: v.model_dump() for k, v in tx.state.equipment.items()},
            }

    async def maintain_equipment(self, game_id: str, item_id: str) -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            inventory = InventorySystem(tx.state, self.content.catalog)
            definition = self.content.catalog.item(item_id)
            if definition is None or not definition.durable:
                raise InvalidInputError(f"'{item_id}' is not a serviceable tool.")
            if not inventory.has(item_id):
                raise InvalidInputError(f"You do not carry '{item_id}'.")

            if inventory.has("maintenance_kit"):
                inventory.remove("maintenance_kit")
                method = "maintenance_kit"
                amount = 45
            else:
                resources = ResourceManager(tx.state, self.content.catalog)
                resources.apply({"power": -5})
                method = "service_station"
                amount = 25

            condition = inventory.restore(item_id, amount)
            tx.state.equipment.setdefault(item_id, EquipmentState())
            payload = {"item": item_id, "condition": condition, "method": method}
            tx.recorder.emit("equipment.maintained", payload)
            return {
                **payload,
                "inventory": dict(tx.state.inventory),
                "resources": dict(tx.state.resources),
            }

    async def set_eva(self, game_id: str, active: bool) -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            oxygen = OxygenSystem(tx.state, self.content.catalog)
            payload = oxygen.set_eva(active)
            tx.recorder.emit("suit.eva", payload)
            return payload

    async def leaderboard(self, limit: int = 10) -> list[dict[str, Any]]:
        async with self.db.session() as session:
            return await GameRepository(session).leaderboard(limit)

    # ------------------------------------------------------------------
    # HUD views (resources / inventory / suit)
    # ------------------------------------------------------------------
    async def resources_view(self, game_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        resources = ResourceManager(state, self.content.catalog)
        return {
            "game_id": game_id,
            "resources": dict(state.resources),
            "caps": dict(state.resource_caps),
            "ratios": {name: resources.ratio(name) for name in state.resources},
            "critical": resources.critical(),
        }

    async def inventory_view(self, game_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        inventory = InventorySystem(state, self.content.catalog)
        carried = dict(state.inventory)
        mass = sum(
            definition.mass_kg * quantity
            for item_id, quantity in carried.items()
            if (definition := self.content.catalog.item(item_id)) is not None
        )
        return {
            "game_id": game_id,
            "inventory": carried,
            "equipment": {k: v.model_dump() for k, v in state.equipment.items()},
            "degraded_tools": inventory.degraded_tools(),
            "capacity": {
                "distinct_items": len(carried),
                "total_units": sum(carried.values()),
                "mass_kg": round_to(mass, 2),
            },
        }

    async def suit_view(self, game_id: str) -> dict[str, Any]:
        state = await self.read_state(game_id)
        oxygen = OxygenSystem(state, self.content.catalog)
        return {
            "game_id": game_id,
            "suit": state.suit.model_dump(),
            "oxygen": state.resources.get("oxygen", 0),
            "oxygen_cap": state.resource_caps.get("oxygen", 100),
            "drain_rates": {
                activity.value: oxygen.rate_for(activity.value) for activity in Activity
            },
            "environment": state.environment.value,
        }

    # ------------------------------------------------------------------
    # Science (Martian Guide lab work)
    # ------------------------------------------------------------------
    async def analyse_sample(self, game_id: str, sample_id: str) -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            analysis = await self.science.analyse(tx.state, sample_id, repository=tx.samples)
            tx.recorder.emit(
                "science.sample_analysed",
                {
                    "sample_id": sample_id,
                    "rock_type": analysis.get("rock_type"),
                    "confidence_pct": analysis.get("confidence_pct"),
                },
                mission_id="martian_guide",
            )
            return analysis

    async def log_finding(self, game_id: str, sample_id: str, *, note: str = "") -> dict[str, Any]:
        async with self.transaction(game_id) as tx:
            finding = await self.science.record_finding(
                tx.state, sample_id, repository=tx.samples, note=note
            )
            tx.recorder.emit("science.finding_logged", finding, mission_id="martian_guide")
            return finding

    # ------------------------------------------------------------------
    # Prototype-01 compatibility
    # ------------------------------------------------------------------
    async def create_legacy_game(self, player_name: str) -> dict[str, Any]:
        """Create a save that matches the original in-memory prototype.

        The prototype started every player with a scanner, a wrench and a
        repair kit, and dropped them straight into the water-leak mission.
        Old frontend builds keep working against the persistent engine.

        Two repair kits are issued, exactly like the Training Facility loadout
        (``take_repair_tools``): repairing a pressurised line destroys one kit,
        so a single wrong-order attempt must stay recoverable.
        """
        created = await self.create_game(player_name=player_name)
        game_id = created["game_id"]
        async with self.transaction(game_id) as tx:
            inventory = InventorySystem(tx.state, self.content.catalog)
            for item_id, quantity in (("scanner", 1), ("wrench", 1), ("repair_kit", 2)):
                inventory.add(item_id, quantity)
            tx.state.world["leak_active"] = True
            progress = tx.state.mission("analog_water_leak")
            progress.status = MissionStatus.available
            self.engine.start(tx.state, "analog_water_leak", tx.recorder)
            tx.recorder.emit(
                "legacy.session_provisioned",
                {"kit": {"scanner": 1, "wrench": 1, "repair_kit": 2}},
            )
        return created
